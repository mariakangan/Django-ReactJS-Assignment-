# alpha_health
Django + ReactJS Assignment for Alpha Health
Local setup :
step 1: install requirements.txt 

`pip install -r requirements.txt`


step 2 : run migrations 

 `python manage.py makemigrations`
 
 `python manage.py migrate`
 
step 3: load fixtures:

`python manage.py loaddata apps/base/fixture.json`

step 4: run application

`python mange.py runserver`

api collection is attached with the code base

play with api 

